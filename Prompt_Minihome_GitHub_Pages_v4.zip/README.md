# Prompt Minihome

싸이월드 미니홈피 감성 + 가벼운 엔젤코어 포인트로 만든 개인용 NAI 프롬프트 아카이브입니다.

## 포함 기능

- 캐릭터 / 기본 프롬프트 / 공용 UC / 장면 / 기타 분류
- 이미지 썸네일 카드
- 프롬프트 전체 복사
- 즐겨찾기
- 검색 / 태그 필터 / 정렬
- 프로필 이미지 / 배너 / 소개글 커스텀
- 컬러 테마 커스텀
- JSON 백업 / 복구
- 브라우저 IndexedDB 로컬 저장

## GitHub Pages에 올리는 방법

1. 새 GitHub 저장소를 만듭니다.
2. 이 폴더의 `index.html`, `.nojekyll`, `README.md`를 저장소 최상단에 업로드합니다.
3. GitHub 저장소의 **Settings → Pages**로 이동합니다.
4. **Build and deployment → Deploy from a branch**를 선택합니다.
5. Branch는 `main`, Folder는 `/ (root)`로 선택하고 저장합니다.
6. 잠시 뒤 Pages 주소로 접속하면 됩니다.

## 데이터 저장 관련

프롬프트와 업로드한 이미지는 GitHub 저장소에 저장되지 않고,
해당 사이트를 연 브라우저의 IndexedDB에 저장됩니다.

따라서 브라우저/기기를 바꾸기 전에는 사이트의 **백업** 버튼으로 JSON 파일을 내려받고,
새 환경에서 **복구** 버튼으로 불러오는 방식이 안전합니다.

## 파일 구조

```text
prompt-minihome-github/
├─ index.html
├─ .nojekyll
└─ README.md
```
